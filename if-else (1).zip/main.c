#include<stdio.h>
int main(){
    int n;
    printf("enter the number: ");
    scanf("%d",&n);
for(n<=100;n=n+1;n++)
    printf("the number is even");
return 0;
}